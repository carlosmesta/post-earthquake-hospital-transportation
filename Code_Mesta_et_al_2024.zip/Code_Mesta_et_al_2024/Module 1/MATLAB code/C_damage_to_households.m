clear;
clc;

nsim=100;

%Reading precomputed GIS info for households (coordinates and pop per household)

filename_gisinfo='C:\Code_Mesta_et_al_2024\Module 1\input_data\GIS_info.csv';
gisinfo_tab=readtable(filename_gisinfo);

parfor i=1:nsim
    name_build=sprintf('buildings_%d.csv',i);
    filename_building=strcat('C:\Code_Mesta_et_al_2024\Module 1\Buildings_withdamage\',name_build);
    building_tab=readtable(filename_building);

    name_house=sprintf('households_%d.csv',i);
    filename_house=strcat('C:\Code_Mesta_et_al_2024\Module 1\Households\',name_house);
    house_tab=readtable(filename_house);

    for h=1:height(house_tab)
        house_tab{h,"Damage"}=building_tab{building_tab.IDblock==house_tab{h,"IDblock"} & building_tab.IDbuilding==house_tab{h,"IDbuilding"},"Damage"};
    end

    %adding missing information: coordinates and population per household
    house_tab=[house_tab gisinfo_tab(:,4:end)];

    write (house_tab,name_house);

end

%save household damage realisations in folder "Households_withdamage"