clear;
clc;

%Reading info for fragility functions and hazard scenario
filename_fragility='C:\Code_Mesta_et_al_2024\Module 1\input_data\fragility_info.csv';
frag_tab=readtable(filename_fragility);
filename_ims='C:\Code_Mesta_et_al_2024\Module 1\input_data\hazardScenarioP75.csv';
ims_tab=readtable(filename_ims);

%Reading building realisations in folder "Buildings"
myFolderIM = 'C:\Code_Mesta_et_al_2024\Module 1\Buildings';
filePatternIM = fullfile(myFolderIM, '**/buildings_*.csv');
theFilesIM = dir(filePatternIM);
nsim=length(theFilesIM);

parfor i=1:nsim
    baseFileName = theFilesIM(i).name;
    fullFileName = fullfile(theFilesIM(i).folder, baseFileName);
    building_table = readtable(fullFileName);

    %adding a new column to store the damage states
    building_table.Damage=zeros(height(building_table),1);

    for b=1:height(building_table)
        %reading parameters from building realisation
        IDzone=building_table{b,"IDzone"};
        IDtypology=building_table{b,"IDtypology"};

        %reading parameters for sampling the damage state
        im_code=frag_tab{frag_tab.ID_typology==IDtypology,"IM_type"};
        im_value=ims_tab{ims_tab.IDzone==IDzone,im_code};
        ds1mean=frag_tab{frag_tab.ID_typology==IDtypology,"DS1_log_mean"};
        ds1std=frag_tab{frag_tab.ID_typology==IDtypology,"DS1_log_std"};
        ds2mean=frag_tab{frag_tab.ID_typology==IDtypology,"DS2_log_mean"};
        ds2std=frag_tab{frag_tab.ID_typology==IDtypology,"DS2_log_std"};
        ds3mean=frag_tab{frag_tab.ID_typology==IDtypology,"DS3_log_mean"};
        ds3std=frag_tab{frag_tab.ID_typology==IDtypology,"DS3_log_std"};
        ds4mean=frag_tab{frag_tab.ID_typology==IDtypology,"DS4_log_mean"};
        ds4std=frag_tab{frag_tab.ID_typology==IDtypology,"DS4_log_std"};
        ds5mult=frag_tab{frag_tab.ID_typology==IDtypology,"DS5_mult"};

        %simulate damage
        p_ds1=logncdf(im_value,ds1mean,ds1std);
        p_ds2=logncdf(im_value,ds2mean,ds2std);
        p_ds3=logncdf(im_value,ds3mean,ds3std);
        p_ds4=logncdf(im_value,ds4mean,ds4std);
        p_ds5=p_ds4*ds5mult;
        
        p_slight=max(p_ds1-p_ds2,0);
        p_moder=max(p_ds2-p_ds3,0);
        p_extens=max(p_ds3-p_ds4,0);
        p_coll=max(p_ds4-p_ds5,0);
        p_structcoll=max(p_ds5,0);
        p_nodam=1-(p_slight+p_moder+p_extens+p_coll+p_structcoll);

        damage_state=randsrc(1,1,[0 1 2 3 4 5; p_nodam p_slight p_moder p_extens p_coll p_structcoll]);
        building_table{b,"Damage"}=damage_state;
    end

write (building_table,baseFileName);
end

%save building damage realisations in folder "Buildings_withdamage"
