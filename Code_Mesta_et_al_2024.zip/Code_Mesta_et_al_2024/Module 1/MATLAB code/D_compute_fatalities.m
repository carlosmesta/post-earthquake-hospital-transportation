clear;
clc;

%Reading info for injury rates
filename_injuryrates='C:\Code_Mesta_et_al_2024\Module 1\input_data\injury_rates.csv';
injuryrates_tab=readtable(filename_injuryrates);

totpop=684283;
nsim=100;

parfor i=1:nsim
    name_house=sprintf('households_%d.csv',i);
    filename_house=strcat('C:\Code_Mesta_et_al_2024\Module 1\Households_withdamage\',name_house);
    house_tab=readtable(filename_house);

%Matrix to store population
    sz_hs = [totpop 12];
    varTypes=["string","double","double","double","double","double","string","double","double","double","double","double"];
    varNames=["District","IDzone","IDblock","IDbuilding","IDhouse","IDtypology","CarOwner","Damage","lat","lon","IDpeople","Severity"];
    people_tab=table('Size',sz_hs,'VariableTypes',varTypes,'VariableNames',varNames);

for t=1:height(house_tab)
    cumulative_pop=0+sum(house_tab{1:t-1,"pop"});

    %sampling damage state for household members
    severity_levels=[0 1 2 3 4];
    dam=house_tab{t,"Damage"};
    idtype=house_tab{t,"IDtypology"};
    
    if dam==1
        severity_rates=injuryrates_tab{idtype, ["DS1_Sev0","DS1_Sev1","DS1_Sev2","DS1_Sev3","DS1_Sev4"]};
    elseif dam==2
        severity_rates=injuryrates_tab{idtype, ["DS2_Sev0","DS2_Sev1","DS2_Sev2","DS2_Sev3","DS2_Sev4"]};
    elseif dam==3
        severity_rates=injuryrates_tab{idtype, ["DS3_Sev0","DS3_Sev1","DS3_Sev2","DS3_Sev3","DS3_Sev4"]};
    elseif dam==4
        severity_rates=injuryrates_tab{idtype, ["DS4_Sev0","DS4_Sev1","DS4_Sev2","DS4_Sev3","DS4_Sev4"]};
    elseif dam==5
        severity_rates=injuryrates_tab{idtype, ["DS5_Sev0","DS5_Sev1","DS5_Sev2","DS5_Sev3","DS5_Sev4"]};        
    else
        severity_rates=[1 0 0 0 0];
    end

    %removing rates equals 0
        check=1;
        while check<=size(severity_rates,2)
            if severity_rates(1,check)==0
                severity_rates(:,check)= [];
                severity_levels(:,check)= [];
            else
                check=check+1;
            end
        end

    sample_injury=randsrc(1,house_tab{t,"pop"},[severity_levels; severity_rates]);

    %assigning values to people in the household
    for pop_loc=1:house_tab{t,"pop"}
        people_tab{pop_loc+cumulative_pop,"District"}=house_tab{t,"District"};
        people_tab{pop_loc+cumulative_pop,"IDzone"}=house_tab{t,"IDzone"};
        people_tab{pop_loc+cumulative_pop,"IDblock"}=house_tab{t,"IDblock"};
        people_tab{pop_loc+cumulative_pop,"IDbuilding"}=house_tab{t,"IDbuilding"};
        people_tab{pop_loc+cumulative_pop,"IDhouse"}=house_tab{t,"IDhouse"};
        people_tab{pop_loc+cumulative_pop,"IDtypology"}=house_tab{t,"IDtypology"};
        people_tab{pop_loc+cumulative_pop,"CarOwner"}=house_tab{t,"CarOwner"};
        people_tab{pop_loc+cumulative_pop,"Damage"}=house_tab{t,"Damage"};
        people_tab{pop_loc+cumulative_pop,"lat"}=house_tab{t,"lat"};
        people_tab{pop_loc+cumulative_pop,"lon"}=house_tab{t,"lon"};
        people_tab{pop_loc+cumulative_pop,"IDpeople"}=pop_loc;
        people_tab{pop_loc+cumulative_pop,"Severity"}=sample_injury(pop_loc);
    end
end

name_peopletab=sprintf('people_%d.csv',i);
write (people_tab,name_peopletab);
end

%save people (casualty) realisations and convert them to shapefiles.
%the shapefiles will be used as input data in the ABM model (Module 2).
