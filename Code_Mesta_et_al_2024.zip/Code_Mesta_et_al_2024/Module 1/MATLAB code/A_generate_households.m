clear;
clc;

simulations=100;

%Reading info from blocks
filename_blocks='C:\Code_Mesta_et_al_2024\Module 1\input_data\blocks_info.csv';
block_tab=readtable(filename_blocks);
%Reading building types proportions
filename_prop='C:\Code_Mesta_et_al_2024\Module 1\input_data\types_proportions.csv';
typ_tab=readtable(filename_prop);

for s=1:simulations

%Creating exposure tables for buildings and households
Buildings=table;
Households=table;

for b=1:height(block_tab)

%Matrix to store the buildings
sz = [1100 8];
varTypes=["string","double","double","double","double","string","double","double"];
varNames=["District","IDzone","IDblock","IDbuilding","IDtypology","Typology","Nhouseholds","CarOrder"];
Out_build_loc=table('Size',sz,'VariableTypes',varTypes,'VariableNames',varNames);

%Reading info from block
District=block_tab{b,"District"}; ID_zone=block_tab{b,"ID_zone"}; ID_block=block_tab{b,"ID_block"}; ID_build=1; target_hs=block_tab{b,"tot_HS"}; gen_hs=0; no_car_hs=block_tab{b,"car_N"};

while 1
%Generating building of a given typology
if District=="Surco"
    ID_typology=randsrc(1,1,[typ_tab.ID_typology';typ_tab.Prop_Surco']);
else
    ID_typology=randsrc(1,1,[typ_tab.ID_typology';typ_tab.Prop_SJM']);
end
Typology=typ_tab{typ_tab.ID_typology==ID_typology,"Typology"};
prob_hs_A=typ_tab{typ_tab.ID_typology==ID_typology,"Prob_hhs_A"};
    build_N_hs=randsrc(1,1,[typ_tab{typ_tab.ID_typology==ID_typology,"N_hhs_A"} typ_tab{typ_tab.ID_typology==ID_typology,"N_hhs_B"}; prob_hs_A 1-prob_hs_A]);
priority_car=typ_tab{typ_tab.ID_typology==ID_typology,"Priority_car"};

Out_build_loc{ID_build,"District"}=District;
Out_build_loc{ID_build,"IDzone"}=ID_zone;
Out_build_loc{ID_build,"IDblock"}=ID_block;
Out_build_loc{ID_build,"IDbuilding"}=ID_build;
Out_build_loc{ID_build,"IDtypology"}=ID_typology;
Out_build_loc{ID_build,"Typology"}=Typology;
Out_build_loc{ID_build,"Nhouseholds"}=build_N_hs;
Out_build_loc{ID_build,"CarOrder"}=priority_car;

gen_hs=gen_hs+build_N_hs;

if gen_hs>=target_hs
    Out_build_loc{ID_build,"Nhouseholds"}=target_hs-sum(Out_build_loc{1:ID_build-1,"Nhouseholds"});
    break
end
ID_build=ID_build+1;
end

Out_build_loc(ID_build+1:end,:)=[];

%Matrix to store households of the buildings
sz_hs = [target_hs 9];
varTypes=["string","double","double","double","double","double","string","double","string"];
varNames=["District","IDzone","IDblock","IDbuilding","IDhouse","IDtypology","Typology","CarOrder","CarOwner"];
Out_hs_loc=table('Size',sz_hs,'VariableTypes',varTypes,'VariableNames',varNames);

for t=1:height(Out_build_loc)
    cumulative_hs=0+sum(Out_build_loc{1:t-1,"Nhouseholds"});
    for hs_loc=1:Out_build_loc{t,"Nhouseholds"}
        Out_hs_loc{hs_loc+cumulative_hs,"District"}=Out_build_loc{t,"District"};
        Out_hs_loc{hs_loc+cumulative_hs,"IDzone"}=Out_build_loc{t,"IDzone"};
        Out_hs_loc{hs_loc+cumulative_hs,"IDblock"}=Out_build_loc{t,"IDblock"};
        Out_hs_loc{hs_loc+cumulative_hs,"IDbuilding"}=Out_build_loc{t,"IDbuilding"};
        Out_hs_loc{hs_loc+cumulative_hs,"IDhouse"}=hs_loc;
        Out_hs_loc{hs_loc+cumulative_hs,"IDtypology"}=Out_build_loc{t,"IDtypology"};
        Out_hs_loc{hs_loc+cumulative_hs,"Typology"}=Out_build_loc{t,"Typology"};
        if Out_build_loc{t,"CarOrder"}==0
            Out_hs_loc{hs_loc+cumulative_hs,"CarOrder"}=rand(1,1);
        else
            Out_hs_loc{hs_loc+cumulative_hs,"CarOrder"}=1.01+rand(1,1);
        end
    end
end

%Sorting table to assign households with "NO" car ownership, prioritsing the households living in the most vulnerable buildings

Out_hs_loc=sortrows(Out_hs_loc,"CarOrder",'ascend');

for t=1:no_car_hs
    Out_hs_loc{t,"CarOwner"}="N";
end

for t=no_car_hs+1:height(Out_hs_loc)
    Out_hs_loc{t,"CarOwner"}="Y";
end

Out_hs_loc=sortrows(Out_hs_loc,["IDbuilding","IDhouse"]);
Out_hs_loc.CarOrder=[];

%Concatenating tables
Buildings=[Buildings; Out_build_loc];
Households=[Households; Out_hs_loc];
end

out_name_build=sprintf('buildings_%d.csv',s);
out_name_hhs=sprintf('households_%d.csv',s);
write (Buildings,out_name_build);
write (Households,out_name_hhs);
end

%save building realisations in folder "Buildings"
%save household realisations in folder "Households"